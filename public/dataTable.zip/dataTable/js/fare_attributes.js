$(document).ready(function(){

    // fetch_data();

    function fetch_data8()
    {
        const dataTable = $('#fare_attributes_data').DataTable({
            "aLengthMenu": [[1, 10, 25, 50, -1], [1, 10, 25, 50, "All"]],
            "iDisplayLength": 10

        });
    }

    function update_data8(id, column_name, value)
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/fareattribute/"+id+"/edit",
            method:"POST",
            data:{id:id, column_name:column_name, value:value},
            success:function(data)
            {
                messageFlash(data,'info');
                $('#fare_attributes_data').DataTable().destroy();
                fetch_data8();
            },
            error:function (data) {
                const errors = $.parseJSON(data.responseText);
                let message='';
                $.each(errors.errors, function (key, value) {
                    message+=value+'<br>';
                });
                messageFlash(message,'error');
            }
        });
        setInterval(function(){
            $('#alert_message').html('');
        }, 2000);
    }

    $(document).on('blur', '.update8', function(){
        const id = $(this).data("id");
        const column_name = $(this).data("column");
        const value = $(this).text();
        update_data8(id, column_name, value);
    });
    $(document).on('change', '.agencyId', function(){
        const id = $(this).data("id");
        const column_name ="agency_id";
        const value = $("option:selected",this).text();
        update_data8(id, column_name, value);
    });

    $('#add8').click(function(){

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.get( '/agency/', function( data ) {

            let agencyField;
            let options='';

            data.forEach(function(element) {
                options+=`<option value="`+element.agency_id+`"> `+element.agency_id+`</option>`;

            });

            agencyField = ` <td >
                                 <select id="faaid_data7" name="" class="" data-id="" >`+
                options
                +`</select>
                                    </td>`;


            let html = '<tr>';
            html += '<td contenteditable id="data1"></td>';
            html += '<td contenteditable id="data2"></td>';
            html += '<td contenteditable id="data3"></td>';
            html += '<td contenteditable id="data4"></td>';
            html += '<td contenteditable id="data5"></td>';
            html += '<td contenteditable id="data6"></td>';
            html +=agencyField;
            html += '<td><button type="button" name="insert" id="insert8" class="btn btn-success btn-xs" data-resource="/fareattribute/">Insert</button></td>';
            html += '</tr>';

            $('#fare_attributes_data tbody').prepend(html);
        });




    });
    $(document).on('click', '#insert8', function(){
        const fare_id = $('#data1').text();
        const price = $('#data2').text();
        const currency_type = $('#data3').text();
        const payment_method = $('#data4').text();
        const transfers = $('#data5').text();
        const transfer_duration = $('#data6').text();
        const agency_id = $('#faaid_data7').find(":selected").text();
        const gtfs = $('#gtfs').text();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/fareattribute/store",
                method:"POST",
                data:{
                    fare_id:fare_id,
                    price:price,
                    currency_type:currency_type,
                    payment_method:payment_method,
                    transfers:transfers,
                    transfer_duration:transfer_duration,
                    agency_id:agency_id,
                    gtfs:gtfs
                },
                success:function(data)
                {
                    messageFlash(data,'success');
                    $('#fare_attributes_data').DataTable().destroy();
                    fetch_data8();

                    setInterval(function(){
                        location.reload();
                    }, 2000);
                },
                error:function (data) {
                    const errors = $.parseJSON(data.responseText);
                    let message='';
                    $.each(errors.errors, function (key, value) {
                        message+=value+'<br>';
                    });
                    messageFlash(message,'error');
                }
            });


    });


    $(document).on('click', '.delete8', function(){
        const id = $(this).attr("id");
        if(confirm("Are you sure you want to remove this?")) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/fareattribute/"+id+"/delete",
                method:"POST",
                data:{id:id},
                success:function(data){
                    messageFlash(data,'success');
                    $('#fare_attributes_data').DataTable().destroy();
                    fetch_data8();
                }
            });
            setInterval(function(){
                location.reload();
            }, 2000);
        }
    });
});
