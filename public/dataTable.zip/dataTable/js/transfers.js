$(document).ready(function(){

    // fetch_data();

    function fetch_data12()
    {
        const dataTable = $('#transfers_data').DataTable({
            "aLengthMenu": [[1, 10, 25, 50, -1], [1, 10, 25, 50, "All"]],
            "iDisplayLength": 10

        });
    }

    function update_data12(id, column_name, value)
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/transfer/"+id+"/edit",
            method:"POST",
            data:{id:id, column_name:column_name, value:value},
            success:function(data)
            {
                // $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
                messageFlash(data,'info');
                $('#transfers_data').DataTable().destroy();
                fetch_data12();
            }
        });
        setInterval(function(){
            $('#alert_message').html('');
        }, 2000);
    }

    $(document).on('blur', '.update12', function(){
        const id = $(this).data("id");
        const column_name = $(this).data("column");
        const value = $(this).text();
        update_data12(id, column_name, value);
    });
    $(document).on('change', '.stopId3', function(){
        const id = $(this).data("id");
        const column_name ="from_stop_id";
        const value = $("option:selected",this).text();
        update_data12(id, column_name, value);
    });
    $(document).on('change', '.stopId2', function(){
        const id = $(this).data("id");
        const column_name ="to_stop_id";
        const value = $("option:selected",this).text();
        update_data12(id, column_name, value);
    });

    $('#add12').click(function(){
// exit();
        let html = '<tr>';
        html += '<td contenteditable id="data1"></td>';
        html += '<td contenteditable id="data2"></td>';
        html += '<td contenteditable id="data3"></td>';
        html += '<td contenteditable id="data4"></td>';
        html += '<td><button type="button" name="insert" id="insert12" class="btn btn-success btn-xs" data-resource="/transfer/">Insert</button></td>';
        html += '</tr>';

        $('#transfers_data tbody').prepend(html);


    });
    $(document).on('click', '#insert12', function(){
        const from_stop_id = $('#data1').text();
        const to_stop_id = $('#data2').text();
        const transfer_type = $('#data3').text();
        const min_transfer_time = $('#data4').text();
        const gtfs = $('#gtfs').text();

        if(
            from_stop_id !== '' &&
            to_stop_id!== ''
        ) {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/transfer/store",
                method:"POST",
                data:{
                    from_stop_id:from_stop_id,
                    to_stop_id:to_stop_id,
                    transfer_type:transfer_type,
                    min_transfer_time:min_transfer_time,
                    gtfs:gtfs
                },
                success:function(data)
                {
                    messageFlash(data,'success');
                    $('#transfers_data').DataTable().destroy();
                    fetch_data12();
                }
            });
            setInterval(function(){
                location.reload();
            }, 2000);
        }
        else
        {
            alert("[From Stop Id, To Stop Id] sont obligatoires");
        }
    });


    $(document).on('click', '.delete12', function(){
        const id = $(this).attr("id");
        if(confirm("Are you sure you want to remove this?")) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/transfer/"+id+"/delete",
                method:"POST",
                data:{id:id},
                success:function(data){
                    messageFlash(data,'success');
                    $('#transfers_data').DataTable().destroy();
                    fetch_data12();
                }
            });
            setInterval(function(){
                location.reload();
            }, 2000);
        }
    });
});
