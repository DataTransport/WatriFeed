$(document).ready(function(){

    // fetch_data();

    function fetch_data2()
    {
        const dataTable = $('#stops_data').DataTable({
            "aLengthMenu": [[1, 10, 25, 50, -1], [1, 10, 25, 50, "All"]],
            "iDisplayLength": 10

        });
    }

    function update_data2(id, column_name, value)
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/stop/"+id+"/edit",
            method:"POST",
            data:{id:id, column_name:column_name, value:value},
            success:function(data)
            {
                // $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
                messageFlash(data,'info');
                $('#stops_data').DataTable().destroy();
                fetch_data2();
            },
            error:function (data) {
                const errors = $.parseJSON(data.responseText);
                let message='';
                $.each(errors.errors, function (key, value) {
                    message+=value+'<br>';
                });
                messageFlash(message,'error');
            }
        });

    }

    $(document).on('blur', '.update2', function(){
        const id = $(this).data("id");
        const column_name = $(this).data("column");
        const value = $(this).text();
        update_data2(id, column_name, value);
    });

    $('#add2').click(function(){
// exit();
        let html = '<tr>';
        html += '<td contenteditable id="data1"></td>';
        html += '<td contenteditable id="data2"></td>';
        html += '<td contenteditable id="data3"></td>';
        html += '<td contenteditable id="data4"></td>';
        html += '<td contenteditable id="data5"></td>';
        html += '<td contenteditable id="data6"></td>';
        html += '<td contenteditable id="data7"></td>';
        html += '<td contenteditable id="data8"></td>';
        html += '<td contenteditable id="data9"></td>';
        html += '<td contenteditable id="data10"></td>';
        html += '<td><button type="button" name="insert" id="insert2" class="btn btn-success btn-xs" data-resource="/stop/">Insert</button></td>';
        html += '</tr>';

        $('#stops_data tbody').prepend(html);



    });
    $(document).on('click', '#insert2', function(){
        const stop_id = $('#data1').text();
        const stop_name = $('#data2').text();
        const stop_desc = $('#data3').text();
        const stop_lat = $('#data4').text();
        const stop_lon = $('#data5').text();
        const stop_url = $('#data6').text();
        const loacation_type = $('#data7').text();
        const parent_station = $('#data8').text();
        const zone_id = $('#data9').text();
        const stop_code = $('#data10').text();
        const gtfs = $('#gtfs').text();

            const resource = $(this).data("resource");
            console.log(resource);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/stop/store",
                method:"POST",
                data:{
                    stop_id:stop_id,
                    stop_name:stop_name,
                    zone_id:zone_id,
                    stop_code:stop_code,
                    stop_desc:stop_desc,
                    stop_lat:stop_lat,
                    stop_lon:stop_lon,
                    stop_url:stop_url,
                    location_type:loacation_type,
                    parent_station:parent_station,
                    gtfs:gtfs
                },
                success:function(data)
                {
                    messageFlash(data,'success');
                    $('#stops_data').DataTable().destroy();
                    fetch_data2();
                    setInterval(function(){
                        location.reload();
                    }, 2000);
                },
                error:function (data) {
                    const errors = $.parseJSON(data.responseText);
                    let message='';
                    $.each(errors.errors, function (key, value) {
                        message+=value+'<br>';
                    });
                    messageFlash(message,'error');
                }
            });

    });


    $(document).on('click', '.delete2', function(){
        const id = $(this).attr("id");
        if(confirm("Are you sure you want to remove this?")) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/stop/"+id+"/delete",
                method:"POST",
                data:{id:id},
                success:function(data){
                    messageFlash(data,'success');
                    $('#stops_data').DataTable().destroy();
                    fetch_data2();
                }
            });
            setInterval(function(){
                location.reload();
            }, 2000);
        }
    });
});
