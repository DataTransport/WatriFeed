$(document).ready(function(){

    // fetch_data();

    function fetch_data11()
    {
        const dataTable = $('#frequencies_data').DataTable({
            "aLengthMenu": [[1, 10, 25, 50, -1], [1, 10, 25, 50, "All"]],
            "iDisplayLength": 10

        });
    }

    function update_data11(id, column_name, value)
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/frequency/"+id+"/edit",
            method:"POST",
            data:{id:id, column_name:column_name, value:value},
            success:function(data)
            {
                // $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
                messageFlash(data,'info');
                $('#frequencies_data').DataTable().destroy();
                fetch_data11();
            }
        });
        setInterval(function(){
            $('#alert_message').html('');
        }, 2000);
    }

    $(document).on('blur', '.update11', function(){
        const id = $(this).data("id");
        const column_name = $(this).data("column");
        const value = $(this).text();
        update_data11(id, column_name, value);
    });
    $(document).on('change', '.tripId2', function(){
        const id = $(this).data("id");
        const column_name ="trip_id";
        const value = $("option:selected",this).text();
        update_data11(id, column_name, value);
    });

    $('#add11').click(function(){
// exit();
        let html = '<tr>';
        html += '<td contenteditable id="data1"></td>';
        html += '<td contenteditable id="data2"></td>';
        html += '<td contenteditable id="data3"></td>';
        html += '<td contenteditable id="data4"></td>';
        html += '<td><button type="button" name="insert" id="insert11" class="btn btn-success btn-xs" data-resource="/frequency/">Insert</button></td>';
        html += '</tr>';

        $('#frequencies_data tbody').prepend(html);


    });
    $(document).on('click', '#insert11', function(){
        const trip_id = $('#data1').text();
        const start_time = $('#data2').text();
        const end_time = $('#data3').text();
        const headway_secs = $('#data4').text();
        const gtfs = $('#gtfs').text();

        if(
            start_time !== '' &&
            trip_id!== '' &&
            end_time!== '' &&
            headway_secs !== ''
        ) {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/frequency/store",
                method:"POST",
                data:{
                    trip_id:trip_id,
                    start_time:start_time,
                    end_time:end_time,
                    headway_secs:headway_secs,
                    gtfs:gtfs
                },
                success:function(data)
                {
                    messageFlash(data,'success');
                    $('#frequencies_data').DataTable().destroy();
                    fetch_data11();
                }
            });
            setInterval(function(){
                location.reload();
            }, 2000);
        }
        else
        {
            alert("[TripID, StartTime,EndTime, HeadwaySecs] sont obligatoires");
        }
    });


    $(document).on('click', '.delete11', function(){
        const id = $(this).attr("id");
        if(confirm("Are you sure you want to remove this?")) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/frequency/"+id+"/delete",
                method:"POST",
                data:{id:id},
                success:function(data){
                    messageFlash(data,'success');
                    $('#frequencies_data').DataTable().destroy();
                    fetch_data11();
                }
            });
            setInterval(function(){
                location.reload();
            }, 2000);
        }
    });
});
