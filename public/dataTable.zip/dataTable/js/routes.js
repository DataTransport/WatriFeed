$(document).ready(function(){

    // fetch_data();

    function fetch_data3()
    {
        const dataTable = $('#routes_data').DataTable({
            "aLengthMenu": [[1, 10, 25, 50, -1], [1, 10, 25, 50, "All"]],
            "iDisplayLength": 10

        });
    }

    function update_data3(id, column_name, value)
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/route/"+id+"/edit",
            method:"POST",
            data:{id:id, column_name:column_name, value:value},
            success:function(data)
            {
                messageFlash(data,'info');
                $('#routes_data').DataTable().destroy();
                fetch_data3();
            },
            error:function (data) {
                const errors = $.parseJSON(data.responseText);
                let message='';
                $.each(errors.errors, function (key, value) {
                    message+=value+'<br>';
                });
                messageFlash(message,'error');
            }
        });
        setInterval(function(){
            $('#alert_message').html('');
        }, 2000);
    }

    $(document).on('blur', '.update3', function(){
        const id = $(this).data("id");
        const column_name = $(this).data("column");
        const value = $(this).text();
        update_data3(id, column_name, value);
    });
    $(document).on('change', '.agencyId', function(){
        const id = $(this).data("id");
        const column_name ="agency_id";
        const value = $("option:selected",this).text();
        update_data3(id, column_name, value);
    });
    $(document).on('change', '.routeType', function(){
        const id = $(this).data("id");
        const column_name ="route_type";
        const value = $("option:selected",this).text();
        // console.dir(value);
        update_data3(id, column_name, value);
    });

    $('#add3').click(function(){
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.get( '/agency/', function( data ) {

            let typesField=` <td >
                                 <select id="rtype_data6" name="" class="" data-id="" >
                                      <option value="0"> 0</option>
                                      <option value="1"> 1</option>
                                      <option value="2"> 2</option>
                                      <option value="3"> 3</option>
                                      <option value="4"> 4</option>
                                      <option value="5"> 5</option>
                                      <option value="6"> 6</option>
                                      <option value="7"> 7</option>
                                 </select>
                                    </td>`;
            let agencyField;
            let options='';

            data.forEach(function(element) {
                options+=`<option value="`+element.agency_id+`"> `+element.agency_id+`</option>`;

            });

                agencyField = ` <td >
                                 <select id="raid_data2" name="" class="" data-id="" >`+
                    options
                                 +`</select>
                                    </td>`;

            let html = '<tr>';


            html += '<td contenteditable id="data1"></td>';
            html +=agencyField;
            // html += '<td contenteditable id="data2"></td>';
            html += '<td contenteditable id="data3"></td>';
            html += '<td contenteditable id="data4"></td>';
            html += '<td contenteditable id="data5"></td>';
            html +=typesField;
            // html += '<td contenteditable id="data6"></td>';
            html += '<td contenteditable id="data7"></td>';
            html += '<td contenteditable id="data8"></td>';
            html += '<td contenteditable id="data9"></td>';
            html += '<td><button type="button" name="insert" id="insert3" class="btn btn-success btn-xs" data-resource="/route/">Insert</button></td>';
            html += '</tr>';

            $('#routes_data tbody').prepend(html);
        });



    });
    $(document).on('click', '#insert3', function(){
        const route_id = $('#data1').text();
        const agency_id = $('#raid_data2').find(":selected").text();
        const route_short_name = $('#data3').text();
        const route_long_name = $('#data4').text();
        const route_desc = $('#data5').text();
        const route_type = $('#rtype_data6').find(":selected").text();
        const route_url = $('#data7').text();
        const route_color = $('#data8').text();
        const route_text_color = $('#data9').text();
        const gtfs = $('#gtfs').text();

            const resource = $(this).data("resource");
            console.log(resource);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/route/store",
                method:"POST",
                data:{
                    route_id:route_id,
                    agency_id:agency_id,
                    route_short_name:route_short_name,
                    route_long_name:route_long_name,
                    route_desc:route_desc,
                    route_type:route_type,
                    route_url:route_url,
                    route_color:route_color,
                    route_text_color:route_text_color,
                    gtfs:gtfs
                },
                success:function(data)
                {
                    messageFlash(data,'success');
                    $('#routes_data').DataTable().destroy();
                    fetch_data3();
                    setInterval(function(){
                        location.reload();
                    }, 2000);
                },
                error:function (data) {
                    const errors = $.parseJSON(data.responseText);
                    let message='';
                    $.each(errors.errors, function (key, value) {
                        message+=value+'<br>';
                    });
                    messageFlash(message,'error');
                }
            });

    });


    $(document).on('click', '.delete3', function(){
        const id = $(this).attr("id");
        if(confirm("Are you sure you want to remove this?")) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/route/"+id+"/delete",
                method:"POST",
                data:{id:id},
                success:function(data){
                    messageFlash(data,'success');
                    $('#routes_data').DataTable().destroy();
                    fetch_data3();
                }
            });
            setInterval(function(){
                location.reload();
            }, 2000);
        }
    });
});
