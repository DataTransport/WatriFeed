$(document).ready(function(){

    // fetch_data();

    function fetch_data7()
    {
        const dataTable = $('#calendar_dates_data').DataTable({
            "aLengthMenu": [[1, 10, 25, 50, -1], [1, 10, 25, 50, "All"]],
            "iDisplayLength": 10

        });
    }

    function update_data7(id, column_name, value)
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/calendardate/"+id+"/edit",
            method:"POST",
            data:{id:id, column_name:column_name, value:value},
            success:function(data)
            {
                messageFlash(data,'info');
                $('#calendar_dates_data').DataTable().destroy();
                fetch_data7();
            },
            error:function (data) {
                const errors = $.parseJSON(data.responseText);
                let message='';
                $.each(errors.errors, function (key, value) {
                    message+=value+'<br>';
                });
                messageFlash(message,'error');
            }
        });
        setInterval(function(){
            $('#alert_message').html('');
        }, 2000);
    }

    $(document).on('blur', '.update7', function(){
        const id = $(this).data("id");
        const column_name = $(this).data("column");
        const value = $(this).text();
        update_data7(id, column_name, value);
    });

    $('#add7').click(function(){
// exit();
        let html = '<tr>';
        html += '<td contenteditable id="data1"></td>';
        html += '<td contenteditable id="data2"></td>';
        html += '<td contenteditable id="data3"></td>';
        html += '<td><button type="button" name="insert" id="insert7" class="btn btn-success btn-xs" data-resource="/calendardate/">Insert</button></td>';
        html += '</tr>';

        $('#calendar_dates_data tbody').prepend(html);


    });
    $(document).on('click', '#insert7', function(){
        const service_id = $('#data1').text();
        const date = $('#data2').text();
        const exception_type = $('#data3').text();
        const gtfs = $('#gtfs').text();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/calendardate/store",
                method:"POST",
                data:{
                    service_id:service_id,
                    date:date,
                    exception_type:exception_type,
                    gtfs:gtfs
                },
                success:function(data)
                {
                    messageFlash(data,'success');
                    $('#calendar_dates_data').DataTable().destroy();
                    fetch_data7();
                    setInterval(function(){
                        location.reload();
                    }, 1000);
                },
                error:function (data) {
                    const errors = $.parseJSON(data.responseText);
                    let message='';
                    $.each(errors.errors, function (key, value) {
                        message+=value+'<br>';
                    });
                    messageFlash(message,'error');
                }
            });

    });


    $(document).on('click', '.delete7', function(){
        const id = $(this).attr("id");
        if(confirm("Are you sure you want to remove this?")) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/calendardate/"+id+"/delete",
                method:"POST",
                data:{id:id},
                success:function(data){
                    messageFlash(data,'success');
                    $('#calendar_dates_data').DataTable().destroy();
                    fetch_data7();
                }
            });
            setInterval(function(){
                location.reload();
            }, 1000);
        }
    });
});
