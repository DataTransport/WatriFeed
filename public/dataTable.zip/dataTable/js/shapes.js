$(document).ready(function(){

    // fetch_data();

    function fetch_data10()
    {
        const dataTable = $('#shapes_data').DataTable({
            "aLengthMenu": [[1, 10, 25, 50, -1], [1, 10, 25, 50, "All"]],
            "iDisplayLength": 10

        });
    }

    function update_data10(id, column_name, value)
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/shape/"+id+"/edit",
            method:"POST",
            data:{id:id, column_name:column_name, value:value},
            success:function(data)
            {
                messageFlash(data,'info');
                $('#shapes_data').DataTable().destroy();
                fetch_data10();
            }
        });
        setInterval(function(){
            $('#alert_message').html('');
        }, 2000);
    }

    $(document).on('blur', '.update10', function(){
        const id = $(this).data("id");
        const column_name = $(this).data("column");
        const value = $(this).text();
        update_data10(id, column_name, value);
    });

    $('#add10').click(function(){
// exit();
        let html = '<tr>';
        html += '<td contenteditable id="data1"></td>';
        html += '<td contenteditable id="data2"></td>';
        html += '<td contenteditable id="data3"></td>';
        html += '<td contenteditable id="data4"></td>';
        html += '<td contenteditable id="data5"></td>';
        html += '<td><button type="button" name="insert" id="insert10" class="btn btn-success btn-xs" data-resource="/shape/">Insert</button></td>';
        html += '</tr>';

        $('#shapes_data tbody').prepend(html);


    });
    $(document).on('click', '#insert10', function(){
        const shape_id = $('#data1').text();
        const shape_pt_lat = $('#data2').text();
        const shape_pt_lon = $('#data3').text();
        const shape_pt_sequence = $('#data4').text();
        const shape_dist_traveled = $('#data5').text();
        const gtfs = $('#gtfs').text();

        if(
            shape_id !== '' &&
            shape_pt_lat!== '' &&
            shape_pt_lon!== '' &&
            shape_pt_sequence!== ''
        ) {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/shape/store",
                method:"POST",
                data:{
                    shape_id:shape_id,
                    shape_pt_lat:shape_pt_lat,
                    shape_pt_lon:shape_pt_lon,
                    shape_pt_sequence:shape_pt_sequence,
                    shape_dist_traveled:shape_dist_traveled,
                    gtfs:gtfs
                },
                success:function(data)
                {
                    messageFlash(data,'success');
                    $('#shapes_data').DataTable().destroy();
                    fetch_data10();
                }
            });
            setInterval(function(){
                location.reload();
            }, 1000);
        }
        else
        {
            alert("[ShapeID, Pt_lat,Pt_lon, Pt_sequence] sont obligatoires");
        }
    });


    $(document).on('click', '.delete10', function(){
        const id = $(this).attr("id");
        if(confirm("Are you sure you want to remove this?")) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/shape/"+id+"/delete",
                method:"POST",
                data:{id:id},
                success:function(data){
                    messageFlash(data,'success');
                    $('#shapes_data').DataTable().destroy();
                    fetch_data10();
                }
            });
            setInterval(function(){
                location.reload();
            }, 1000);
        }
    });
});
