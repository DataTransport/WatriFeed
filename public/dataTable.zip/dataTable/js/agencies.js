$(document).ready(function(){

    // fetch_data();

    function fetch_data()
    {
        const dataTable = $('#agencies_data').DataTable({

            "aLengthMenu": [[1, 10, 25, 50, -1], [1, 10, 25, 50, "All"]],
            "iDisplayLength": 10

        });

    }
    function messageFlash(message,type="success") {
        let opts = {
            "closeButton": true,
            "debug": false,
            "positionClass": rtl() || public_vars.$pageContainer.hasClass('right-sidebar') ? "toast-top-left" : "toast-top-right",
            "toastClass": "red",
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };
        if (type==='success'){
            toastr.success(message,opts);
        }else if(type==='info'){
            toastr.info(message,opts);
        }else {
            toastr.error(message,opts);
        }


    }

    function update_data(id, column_name, value)
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/agency/"+id+"/edit",
            method:"POST",
            data:{id:id, column_name:column_name, value:value},
            success:function(data)
            {
                messageFlash(data,'info');
                $('#agencies_data').DataTable().destroy();
                fetch_data();
            },
            error:function (data) {
                const errors = $.parseJSON(data.responseText);
                let message='';
                $.each(errors.errors, function (key, value) {
                    message+=value+'<br>';
                });
                messageFlash(message,'error');
            }
        });
        setInterval(function(){
            $('#alert_message').html('');
        }, 2000);
    }

    $(document).on('blur', '.update', function(){
        const id = $(this).data("id");
        const column_name = $(this).data("column");
        var value = $(this).text();
        update_data(id, column_name, value);
    });

    $('#add1').click(function(){
        let html = '<tr>';
        html += '<td contenteditable id="data1"></td>';
        html += '<td contenteditable id="data2"></td>';
        html += '<td contenteditable id="data3"></td>';
        html += '<td contenteditable id="data4"></td>';
        html += '<td contenteditable id="data5"></td>';
        html += '<td contenteditable id="data6"></td>';
        html += '<td><button type="button" name="insert" id="insert1" class="btn btn-success btn-xs" data-resource="/agency/">Insert</button></td>';
        html += '</tr>';
        $('#agencies_data tbody').prepend(html);
    });
    $(document).on('click', '#insert1', function(){
        const agency_id = $('#data1').text();
        const agency_name = $('#data2').text();
        const agency_url = $('#data3').text();
        const agency_timezone = $('#data4').text();
        const agency_phone = $('#data5').text();
        const agency_lang = $('#data6').text();
        const gtfs = $('#gtfs').text();



            var resource = $(this).data("resource");
            console.log(resource);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({


                url:"/agency/store",
                method:"POST",
                data:{
                    agency_id:agency_id,
                    agency_name:agency_name,
                    agency_url:agency_url,
                    agency_timezone:agency_timezone,
                    agency_lang:agency_lang,
                    agency_phone:agency_phone,
                    gtfs:gtfs
                },
                success:function(data)
                {
                    messageFlash(data,'success');
                    $('#agencies_data').DataTable().destroy();
                    fetch_data();
                    setInterval(function(){
                        location.reload();
                    }, 2000);
                },
                error:function (data) {
                    const errors = $.parseJSON(data.responseText);
                    let message='';
                    $.each(errors.errors, function (key, value) {
                        message+=value+'<br>';
                    });
                    messageFlash(message,'error');
                }
            });

    });


    $(document).on('click', '.delete1', function(){
        const id = $(this).attr("id");
        if(confirm("Are you sure you want to remove this?")) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/agency/"+id+"/delete",
                method:"POST",
                data:{id:id},
                success:function(data){
                    messageFlash(data,'success');
                    $('#agencies_data').DataTable().destroy();
                    fetch_data();
                }
            });
            setInterval(function(){
                location.reload();
            }, 2000);
        }
    });
});
