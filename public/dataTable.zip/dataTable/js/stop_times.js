$(document).ready(function(){

    // fetch_data();

    function fetch_data5()
    {
        const dataTable = $('#stop_times_data').DataTable({
            "aLengthMenu": [[1, 10, 25, 50, -1], [1, 10, 25, 50, "All"]],
            "iDisplayLength": 10

        });
    }

    function update_data5(id, column_name, value)
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/stoptime/"+id+"/edit",
            method:"POST",
            data:{id:id, column_name:column_name, value:value},
            success:function(data)
            {
                messageFlash(data,'info');
                $('#stop_times_data').DataTable().destroy();
                fetch_data5();
            },
            error:function (data) {
                const errors = $.parseJSON(data.responseText);
                let message='';
                $.each(errors.errors, function (key, value) {
                    message+=value+'<br>';
                });
                messageFlash(message,'error');
            }
        });
        setInterval(function(){
            $('#alert_message').html('');
        }, 2000);
    }

    $(document).on('blur', '.update5', function(){
        const id = $(this).data("id");
        const column_name = $(this).data("column");
        const value = $(this).text();
        update_data5(id, column_name, value);
    });
    $(document).on('change', '.tripId', function(){
        const id = $(this).data("id");
        const column_name ="trip_id";
        const value = $("option:selected",this).text();
        update_data5(id, column_name, value);
    });
    $(document).on('change', '.stopId', function(){
        const id = $(this).data("id");
        const column_name ="stop_id";
        const value = $("option:selected",this).text();
        update_data5(id, column_name, value);
    });

    $('#add5').click(function(){

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.get( '/trip/', function( data1 ) {

            let tripField;
            let stopField;
            let options='';
            let options2='';


            data1.forEach(function(element) {
                options+=`<option value="`+element.trip_id+`"> `+element.trip_id+`</option>`;

            });

            tripField = ` <td >
                                 <select id="stid_data1" name="" class="" data-id="" >`+
                options
                +`</select>
                                    </td>`;

            $.get( '/stop/', function( data ) {
                console.dir(data);
                data.forEach(function(element2) {
                    options2+=`<option value="`+element2.stop_id+`"> `+element2.stop_id+`</option>`;

                });

                stopField = ` <td >
                                 <select id="ssid_data4" name="" class="" data-id="" >`+
                    options2
                    +`</select>
                                    </td>`;


                let html = '<tr>';
                html +=tripField;
                html += '<td contenteditable id="data2"></td>';
                html += '<td contenteditable id="data3"></td>';
                html +=stopField;
                html += '<td contenteditable id="data5"></td>';
                html += '<td contenteditable id="data6"></td>';
                html += '<td contenteditable id="data7"></td>';
                html += '<td contenteditable id="data8"></td>';
                html += '<td contenteditable id="data9"></td>';
                html += '<td><button type="button" name="insert" id="insert5" class="btn btn-success btn-xs" data-resource="/stoptime/">Insert</button></td>';
                html += '</tr>';

                $('#stop_times_data tbody').prepend(html);
            });

        });




    });
    $(document).on('click', '#insert5', function(){
        const trip_id = $('#stid_data1').find(":selected").text();
        const arrival_time = $('#data2').text();
        const departure_time = $('#data3').text();
        const stop_id = $('#ssid_data4').find(":selected").text();
        const stop_sequence = $('#data5').text();
        const stop_headsign = $('#data6').text();
        const pickup_type = $('#data7').text();
        const drop_off_type = $('#data8').text();
        const shape_dist_traveled = $('#data9').text();
        const gtfs = $('#gtfs').text();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/stoptime/store",
                method:"POST",
                data:{
                    trip_id:trip_id,
                    arrival_time:arrival_time,
                    departure_time:departure_time,
                    stop_id:stop_id,
                    stop_sequence:stop_sequence,
                    stop_headsign:stop_headsign,
                    pickup_type:pickup_type,
                    drop_off_type:drop_off_type,
                    shape_dist_traveled:shape_dist_traveled,
                    gtfs:gtfs
                },
                success:function(data)
                {
                    messageFlash(data,'success');
                    $('#stop_times_data').DataTable().destroy();
                    fetch_data5();
                    setInterval(function(){
                        location.reload();
                    }, 2000);
                },
                error:function (data) {
                    const errors = $.parseJSON(data.responseText);
                    let message='';
                    $.each(errors.errors, function (key, value) {
                        message+=value+'<br>';
                    });
                    messageFlash(message,'error');
                }
            });


    });


    $(document).on('click', '.delete5', function(){
        const id = $(this).attr("id");
        if(confirm("Are you sure you want to remove this?")) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/stoptime/"+id+"/delete",
                method:"POST",
                data:{id:id},
                success:function(data){
                    messageFlash(data,'success');
                    $('#stop_times_data').DataTable().destroy();
                    fetch_data5();
                }
            });
            setInterval(function(){
                location.reload();
            }, 2000);
        }
    });
});
