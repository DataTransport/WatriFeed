$(document).ready(function(){

    // fetch_data();

    function fetch_data6()
    {
        const dataTable = $('#calendars_data').DataTable({
            "aLengthMenu": [[1, 10, 25, 50, -1], [1, 10, 25, 50, "All"]],
            "iDisplayLength": 10

        });
    }

    function update_data6(id, column_name, value)
    {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url:"/calendar/"+id+"/edit",
            method:"POST",
            data:{id:id, column_name:column_name, value:value},
            success:function(data)
            {
                // $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');

                messageFlash(data,'info');
                $('#calendars_data').DataTable().destroy();
                fetch_data6();
            },
            error:function (data) {
                const errors = $.parseJSON(data.responseText);
                let message='';
                $.each(errors.errors, function (key, value) {
                    message+=value+'<br>';
                });
                messageFlash(message,'error');
            }
        });
        setInterval(function(){
            $('#alert_message').html('');
        }, 2000);
    }

    $(document).on('blur', '.update6', function(){
        const id = $(this).data("id");
        const column_name = $(this).data("column");
        const value = $(this).text();
        update_data6(id, column_name, value);
    });
    $(document).on('change', '.tripId', function(){
        const id = $(this).data("id");
        const column_name ="trip_id";
        const value = $("option:selected",this).text();
        update_data6(id, column_name, value);
    });
    $(document).on('change', '.stopId', function(){
        const id = $(this).data("id");
        const column_name ="stop_id";
        const value = $("option:selected",this).text();
        update_data6(id, column_name, value);
    });

    $('#add6').click(function(){
// exit();
        let html = '<tr>';
        html += '<td contenteditable id="data1"></td>';
        html += '<td contenteditable id="data2"></td>';
        html += '<td contenteditable id="data3"></td>';
        html += '<td contenteditable id="data4"></td>';
        html += '<td contenteditable id="data5"></td>';
        html += '<td contenteditable id="data6"></td>';
        html += '<td contenteditable id="data7"></td>';
        html += '<td contenteditable id="data8"></td>';
        html += '<td contenteditable id="data9"></td>';
        html += '<td contenteditable id="data10"></td>';
        html += '<td><button type="button" name="insert" id="insert6" class="btn btn-success btn-xs" data-resource="/calendar/">Insert</button></td>';
        html += '</tr>';

        $('#calendars_data tbody').prepend(html);


    });
    $(document).on('click', '#insert6', function(){
        const service_id = $('#data1').text();
        const monday = $('#data2').text();
        const tuesday = $('#data3').text();
        const wednesday = $('#data4').text();
        const thursday = $('#data5').text();
        const friday = $('#data6').text();
        const saturday = $('#data7').text();
        const sunday = $('#data8').text();
        const start_date = $('#data9').text();
        const end_date = $('#data10').text();
        const gtfs = $('#gtfs').text();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/calendar/store",
                method:"POST",
                data:{
                    service_id:service_id,
                    monday:monday,
                    tuesday:tuesday,
                    wednesday:wednesday,
                    thursday:thursday,
                    friday:friday,
                    saturday:saturday,
                    sunday:sunday,
                    start_date:start_date,
                    end_date:end_date,
                    gtfs:gtfs
                },
                success:function(data)
                {
                    console.dir(data);
                    messageFlash(data,'success');
                    $('#calendars_data').DataTable().destroy();
                    fetch_data6();
                    setInterval(function(){
                        location.reload();
                    }, 2000);
                },
                error:function (data) {
                    const errors = $.parseJSON(data.responseText);
                    let message='';
                    $.each(errors.errors, function (key, value) {
                     message+=value+'<br>';
                    });
                    messageFlash(message,'error');
                }
            });

    });


    $(document).on('click', '.delete6', function(){
        const id = $(this).attr("id");
        if(confirm("Are you sure you want to remove this?")) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url:"/calendar/"+id+"/delete",
                method:"POST",
                data:{id:id},
                success:function(data){
                    messageFlash(data,'success');
                    $('#calendars_data').DataTable().destroy();
                    fetch_data6();
                }
            });
            setInterval(function(){
                location.reload();
            }, 2000);
        }
    });
});
