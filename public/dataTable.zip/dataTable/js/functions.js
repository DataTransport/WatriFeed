function messageFlash(message,type="success") {
    let opts = {
        "closeButton": true,
        "debug": false,
        "positionClass": "toast-top-full-width",
        "toastClass": "red",
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    if (type==='success'){
        toastr.success(message,opts);
    }else if(type==='info'){
        toastr.info(message,opts);
    }else {
        toastr.error(message,opts);
    }


}
